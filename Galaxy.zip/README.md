# 🌌 Galaxy

<p align="center">
  <img src="https://github.com/user-attachments/assets/80d41731-a655-4dd0-abf8-ace564a3c500" alt="Galaxy Preview">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue?logo=python" alt="Python">
  <img src="https://img.shields.io/badge/Framework-Kivy-green?logo=kivy" alt="Kivy">
</p>

### 📦 Supported Platforms
- **Windows:** `.exe`
- **Android:** `.apk`
- **macOS:** `.dmg`

---

> 📁 **[Access the Technical Documentation PDF here](docs/BuildingGalaxy.pdf)**

---

## 📜 Credits & License
This project is based on the "Galaxy" game created by **Jonathan Rue** as part of a comprehensive Kivy course. All rights for the initial version of this project belong to the original author.

As stated by the author in the tutorial, the project is open for modification and personal development. I would also like to extend a special thanks to **freeCodeCamp.org** for their incredible mission to provide free, high-quality coding education to everyone, everywhere.

A special thanks to **[Florin57](https://github.com/Florin57)** for his assistance in creating the application build for the macOS platform.

_GIF created using [VEED.io](https://www.veed.io/)._

**Note:** This is a **non-commercial, educational project** created for learning purposes.

## 🛠️ Local Development Setup

Follow these steps to configure the source code on your machine.

### 1. Clone the Repository

```bash
git clone https://github.com/davidCrejenovschi/Galaxy.git
```

```bash
cd Galaxy
```

### 2. Create and Activate a Virtual Environment

**Windows:**

```bash
python -m venv venv
```

```bash
venv\Scripts\activate
```

**macOS / Linux:**

```bash
python3 -m venv venv
```

```bash
python3 -m venv venv
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the Project

```bash
python main.py
```
